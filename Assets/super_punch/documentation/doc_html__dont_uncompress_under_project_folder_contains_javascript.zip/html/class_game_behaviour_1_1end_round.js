var class_game_behaviour_1_1end_round =
[
    [ "endRound", "class_game_behaviour_1_1end_round.html#a756f20c7fb8bc1408ff92a17aed9107e", null ],
    [ "Act", "class_game_behaviour_1_1end_round.html#a3a8b6418f4d9e67915fb23e323c41cc5", null ],
    [ "DoBeforeEntering", "class_game_behaviour_1_1end_round.html#ac487ee28273326d022f0dab1e403a57a", null ],
    [ "DoBeforeLeaving", "class_game_behaviour_1_1end_round.html#a8147052ca0f1e571f2d19c99fd92f705", null ],
    [ "Reason", "class_game_behaviour_1_1end_round.html#aeaf777a81cd2314b1a88a02c178fb345", null ]
];