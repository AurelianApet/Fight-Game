var class_fighter_injured_behaviour =
[
    [ "setInjuries", "class_fighter_injured_behaviour.html#a6afa8f38dff79a81598bbed42999c79f", null ],
    [ "Avatar", "class_fighter_injured_behaviour.html#ae555b6d6da127457cb971d240de010fd", null ],
    [ "Body", "class_fighter_injured_behaviour.html#ad89eebf02dc7319096d37e4524dc0f2f", null ],
    [ "Damage", "class_fighter_injured_behaviour.html#a557d8bb1c054f53393bf73a72c3afb8f", null ],
    [ "HitLimit", "class_fighter_injured_behaviour.html#a498932a2c597603a04dfa1fd65155ad6", null ],
    [ "Injuries", "class_fighter_injured_behaviour.html#aec40223f520119f372e8c77edb367b41", null ]
];