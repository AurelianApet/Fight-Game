var class_hit_data =
[
    [ "damage", "class_hit_data.html#a172ed2578553e274bc5b8c7e626b624f", null ],
    [ "tag", "class_hit_data.html#a0a08430f4057a5ebcd7f592aa82c16c7", null ]
];