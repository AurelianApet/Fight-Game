var searchData=
[
  ['activeinjured',['activeInjured',['../class_fighter_controller.html#abc341a74379490ef8cde231cbcc0c22b',1,'FighterController']]],
  ['angryspectators',['AngrySpectators',['../class_game_behaviour.html#a180cc94bf358f8bf32051bb9e8f5e173',1,'GameBehaviour']]],
  ['avatar',['Avatar',['../class_fighter_controller.html#a8577cdd8e6876b61b5865e4e4aeb9ec0',1,'FighterController.Avatar()'],['../class_fighter_injured_behaviour.html#ae555b6d6da127457cb971d240de010fd',1,'FighterInjuredBehaviour.Avatar()']]]
];
