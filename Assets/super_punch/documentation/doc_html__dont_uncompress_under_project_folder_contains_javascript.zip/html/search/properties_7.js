var searchData=
[
  ['injuredavatar',['InjuredAvatar',['../class_fighter_controller.html#a2eff08306b5b739104e631392a1c9df5',1,'FighterController']]],
  ['injureddamage',['InjuredDamage',['../class_fighter_controller.html#a5f12f472936f486e040ee179bdda47b0',1,'FighterController']]],
  ['injuries',['Injuries',['../class_fighter_controller.html#a9f679ab096af85e5082e8281166d935b',1,'FighterController.Injuries()'],['../class_fighter_injured_behaviour.html#aec40223f520119f372e8c77edb367b41',1,'FighterInjuredBehaviour.Injuries()']]],
  ['isactive',['IsActive',['../class_fighter_controller.html#a4ae3d195eb366a34b120b5f78176c8a4',1,'FighterController']]],
  ['isdead',['isDead',['../class_fighter_controller.html#a4c01fafbf4a4b32dc12b3d324fecd7e8',1,'FighterController']]],
  ['ishuman',['IsHuman',['../class_fighter_controller.html#afa4efa33886a66713aae15c48c1ff281',1,'FighterController']]],
  ['issuperpunchloaded',['isSuperPunchLoaded',['../class_fighter_controller.html#a53ca48c23964c703309d290c6ba2ecb0',1,'FighterController']]]
];
