var searchData=
[
  ['initializevariables',['initializeVariables',['../class_fighter_controller.html#a15fe93058c0d96ecc2f248d1523cdc1f',1,'FighterController']]]
];
