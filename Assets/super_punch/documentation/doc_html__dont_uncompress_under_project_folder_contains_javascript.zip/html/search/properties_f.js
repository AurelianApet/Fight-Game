var searchData=
[
  ['tag',['Tag',['../class_fighter_controller.html#a009084fdbf4001889ab5e2e4593925b1',1,'FighterController']]],
  ['totalsucceedhits',['TotalSucceedHits',['../class_fighter_controller.html#ae17f00887daa92cb4b24007d689246c6',1,'FighterController']]]
];
