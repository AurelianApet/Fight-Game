var class_finger_event =
[
    [ "FingerEvent", "class_finger_event.html#a8ff62451ad0a7ccca0a2ef33f974214c", null ],
    [ "Add", "class_finger_event.html#af22ce0686ca54fbfa301229670f73536", null ],
    [ "clearList", "class_finger_event.html#a92e1b2970a34c3c188739499e6e672d7", null ],
    [ "containsObject", "class_finger_event.html#ab5a68cf47ce1d4bc3b8d765a3d8148c3", null ],
    [ "getLast", "class_finger_event.html#a6f37faa3835b4bda41fa30564b1bb888", null ],
    [ "remove", "class_finger_event.html#a2fee0821cb75c4d6d2449cb5e4651650", null ],
    [ "touchedObjects", "class_finger_event.html#abb3f8378fda5ebb02f6ab97656fe1625", null ]
];