var class_game_behaviour_1_1_player_wins =
[
    [ "PlayerWins", "class_game_behaviour_1_1_player_wins.html#aec6a180863968eb83ed5003e7332dcca", null ],
    [ "Act", "class_game_behaviour_1_1_player_wins.html#a6e59ab0283f0df74dec18cba571ace9d", null ],
    [ "DoBeforeEntering", "class_game_behaviour_1_1_player_wins.html#a2c99d7f73040d6f28d4ef94f11c5f125", null ],
    [ "DoBeforeLeaving", "class_game_behaviour_1_1_player_wins.html#a5b5bc22ccabd575449a59a929df49bad", null ],
    [ "Reason", "class_game_behaviour_1_1_player_wins.html#a77193768823edfc26767c2cc59e19dd1", null ]
];