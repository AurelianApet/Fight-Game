var class_game_behaviour_1_1_player_loses =
[
    [ "PlayerLoses", "class_game_behaviour_1_1_player_loses.html#a08ebcb4e601593ad9102a271e611daf2", null ],
    [ "Act", "class_game_behaviour_1_1_player_loses.html#a25f180d7d7c932616365b19ceab27571", null ],
    [ "DoBeforeEntering", "class_game_behaviour_1_1_player_loses.html#ac9223b5e8c8407aa8332e3c93d861ec7", null ],
    [ "DoBeforeLeaving", "class_game_behaviour_1_1_player_loses.html#af75068cfa689a216d9b628009dbb1ff7", null ],
    [ "Reason", "class_game_behaviour_1_1_player_loses.html#a6d04f80eb4941a8db93c191f8e48623a", null ]
];