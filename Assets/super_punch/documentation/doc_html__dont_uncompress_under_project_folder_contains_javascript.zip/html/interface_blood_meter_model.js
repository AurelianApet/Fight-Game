var interface_blood_meter_model =
[
    [ "MaxBlood", "interface_blood_meter_model.html#a134748db2b1a495674a5b707871a4bb3", null ],
    [ "Measure", "interface_blood_meter_model.html#a7a58bbbfc3ed844cf0d283caf0d8cf4c", null ],
    [ "RelativeMeasure", "interface_blood_meter_model.html#aa56401a1d2c5bc50a68095e5c8330adb", null ]
];