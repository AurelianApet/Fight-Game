var class_object_behaviour =
[
    [ "blink", "class_object_behaviour.html#abbc07a7d0566cabddfd5715779e88efa", null ],
    [ "blinkRate", "class_object_behaviour.html#a48e822ab27a3f1e2a66ad9a60c9c2edb", null ],
    [ "damage", "class_object_behaviour.html#ac97908c82b16b977065db13bf67e218b", null ],
    [ "rotationSpeed", "class_object_behaviour.html#acc503da8dc9f53c59d3ad48f6750ab36", null ],
    [ "timeOutRange", "class_object_behaviour.html#a2bd761c08ed27a5b1ec75b69293b078b", null ]
];