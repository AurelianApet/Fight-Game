var class_game_behaviour_1_1_init_combat =
[
    [ "InitCombat", "class_game_behaviour_1_1_init_combat.html#a522c875b6b62f7e0e3f0f7b5c915a5f3", null ],
    [ "Act", "class_game_behaviour_1_1_init_combat.html#a7602699f07dd8b0561caeee10e2996c9", null ],
    [ "DoBeforeEntering", "class_game_behaviour_1_1_init_combat.html#a67c03eeaf85e1938a0c9d778f32253fb", null ],
    [ "DoBeforeLeaving", "class_game_behaviour_1_1_init_combat.html#a18938d3c8dd0f944d6e9c4e03334113e", null ],
    [ "Reason", "class_game_behaviour_1_1_init_combat.html#a593a5abc8b21bafcdfbb8eb4c2bc7886", null ]
];