var class_play_hurt_effects =
[
    [ "ApplyDamage", "class_play_hurt_effects.html#a03e945de9f7889c09bc73184082da92b", null ],
    [ "hurtSFX", "class_play_hurt_effects.html#a321c1f88f31f258ebc7f685c36cd97a0", null ],
    [ "particles", "class_play_hurt_effects.html#af80e5b4fb3e51465666c99d7ae25b6d9", null ]
];